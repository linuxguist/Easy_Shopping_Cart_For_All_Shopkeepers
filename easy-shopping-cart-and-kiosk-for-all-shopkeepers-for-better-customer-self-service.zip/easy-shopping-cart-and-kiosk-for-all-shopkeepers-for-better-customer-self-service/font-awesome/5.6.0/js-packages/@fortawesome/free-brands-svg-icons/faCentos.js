'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'centos';
var width = 447;
var height = 512;
var ligatures = [];
var unicode = 'f789';
var svgPathData = 'M289.6 97.8l31.6 31.7-76.3 76.5V97.8h44.7zm-162.4 31.7l76.3 76.5V97.8h-44.7l-31.6 31.7zm41.5-41.6h44.7v127.9l10.8 10.8 10.8-10.8V87.9h44.7l-55.5-55.6-55.5 55.6zM194.9 256l-10.8-10.8H55.5v-44.8L0 256l55.5 55.6v-44.8h128.6l10.8-10.8zm79.3-20.7h107.9v-44.8l-31.6-31.7-76.3 76.5zM447.5 256L392 200.4v44.8H264.3L253.5 256l10.8 10.8H392v44.8l55.5-55.6zM65.4 176.5l32.5-31.7 90.3 90.5h15.3V220l-90.3-90.5 31.6-31.7H65.4v78.7zm316.7-78.7h-78.5l31.6 31.7-90.3 90.5v15.3h15.3l90.3-90.5 31.6 31.7V97.8zM203.5 414.2V306.1l-76.3 76.5 31.6 31.7h44.7zM65.4 235.3h108.8l-76.3-76.5-32.5 31.7v44.8zm316.7 100.2l-31.6 31.7-90.3-90.5h-15.3V292l90.3 90.5-31.6 31.7h78.5v-78.7zm0-58.8H274.2l76.3 76.5 31.6-31.7v-44.8zm-60.9 105.8L244.9 306v108.1h44.7l31.6-31.6zM97.9 353.2l76.3-76.5H65.4v44.8l32.5 31.7zm181.8 70.9H235V296.2l-10.8-10.8-10.8 10.8v127.9h-44.7l55.5 55.6 55.5-55.6zm-166.5-41.6l90.3-90.5v-15.3h-15.3l-90.3 90.5-32.5-31.7v78.7h79.4l-31.6-31.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faCentos = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;